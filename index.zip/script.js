const carrinho = document.querySelector ("#carrinho");
const Carrinhoclicado = document.querySelector ("#Carrinhoclicado");
const carrinhovoltar = document.querySelector ("#carrinhovoltar")

carrinho.addEventListener('click', function(){
  Carrinhoclicado.classList.remove("hidden");
});

carrinhovoltar.addEventListener('click', function(){
  Carrinhoclicado.classList.add('hidden')
})

const pesquisar = document.querySelector("#pesquisar")
const inputpesquisar = document.querySelector("#inputpesquisar")

pesquisar.addEventListener('click', function(event){
  event.stopPropagation(); // impede que o clique feche imediatamente
  inputpesquisar.classList.remove("hidden");
  pesquisar.classList.add('hidden');
});

document.addEventListener('click', function(event){
  // se o input estiver visível e o clique foi fora dele
  if (!inputpesquisar.classList.contains("hidden") && !inputpesquisar.contains(event.target)) {
    inputpesquisar.classList.add("hidden");
    pesquisar.classList.remove("hidden");
  }
});
