let lastScrollTop = 0;
const header = document.getElementById("header");

window.addEventListener("scroll", function () {
  const scrollTop = window.pageYOffset || document.documentElement.scrollTop;

  if (scrollTop > lastScrollTop) {
    // rolando para baixo
    header.style.top = "-100px";
  } else {
    // rolando para cima
    header.style.top = "0";
  }

  lastScrollTop = scrollTop <= 0 ? 0 : scrollTop;
});