const carrinho = document.querySelector ("#carrinho");
const Carrinhoclicado = document.querySelector ("#Carrinhoclicado");
const carrinhovoltar = document.querySelector ("#carrinhovoltar")

carrinho.addEventListener('click', function(){
  Carrinhoclicado.classList.remove("hidden");
});

carrinhovoltar.addEventListener('click', function(){
  Carrinhoclicado.classList.add('hidden')
})

const pesquisar = document.querySelector("#pesquisar")
const inputpesquisar = document.querySelector("#inputpesquisar")

pesquisar.addEventListener('click', function(event){
  event.stopPropagation();
  inputpesquisar.classList.remove("hidden");
  pesquisar.classList.add('hidden');
});

document.addEventListener('click', function(event){
  if (!inputpesquisar.classList.contains("hidden") && !inputpesquisar.contains(event.target)) {
    inputpesquisar.classList.add("hidden");
    pesquisar.classList.remove("hidden");
  }
});

const teladelogin = document.querySelector ("#teladelogin")
const continuarsemcadastro = document.querySelector ("#continuarsemcadastro")
const Login = document.querySelector ("#Login")
const body = document.querySelector ("#body")

Login.addEventListener('click', function(event){
  teladelogin.classList.remove('opacity-0', 'pointer-events-none');
  teladelogin.classList.add('opacity-100')
  body.classList.add('overflow-hidden')
})

continuarsemcadastro.addEventListener('click', function(event){
  teladelogin.classList.add('opacity-0', 'pointer-events-none')
  teladelogin.classList.remove('opacity-100')
  body.classList.remove('overflow-hidden')
})
